#!/bin/bash
# ord=$1
# fil=$2
source ./fu.sh

clear 
echo "set status x"
echo Datei: "$1"
# echo $1/x$2


confirm "hide"
# mv $1/$2 $1/x$2
echo x hidden >> $1
# newfile=$(./setstatus.sh $1 "x")
#locdat2svr





