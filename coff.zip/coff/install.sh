#!/bin/bash
# fedora
sudo dnf in fzf nnn wkhtmltopdf
# ubuntu  
#sudo apt install fzf nnn  wkhtmltopdf 
